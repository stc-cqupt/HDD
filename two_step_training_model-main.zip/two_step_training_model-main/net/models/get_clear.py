import numpy as np
import spectral
import data_1
import cv2
import torch

def get_hazeintensitymap_F(x):
    #x = x.cpu()
    x = x.numpy()
    arr_visible = x[:,0:30]
    arr_infrared = x[:,173:209]
    B, C_visible,H, W = arr_visible.shape
    B,C_infrared, H,W = arr_infrared.shape
    sum_vis = np.zeros((B,W, H), dtype=np.float)   # 若batch为2这里要改正
    sum_inf = np.zeros((B,W, H), dtype=np.float)
    for i in range(C_visible):
        sum_vis = sum_vis + arr_visible[:,i]	# 若batch为2这里要改正
    var_vis = sum_vis/C_visible
    for i in range(C_infrared):
        sum_inf = sum_inf + arr_infrared[:,i]
    var_inf = sum_inf / C_infrared  # BHW
    F = var_inf - var_vis   # BHW
    F_final = np.zeros((256,B,256, 256), dtype=np.float)    # cbhw
    for i in range(256):
        F_final[i] = F
    F_final = np.transpose(F_final,(1,0,2,3))
    F_final = torch.Tensor(F_final)
    return F_final

def Rgb2Hsi(r, g, b):
    eps = 1e-8
    img_i = (r + g + b) / 3  # I分量

    img_h = np.zeros(r.shape, dtype=np.float32)
    img_s = np.zeros(r.shape, dtype=np.float32)
    min_rgb = np.zeros(r.shape, dtype=np.float32)
    # 获取RGB中最小值
    min_rgb = np.where((r <= g) & (r <= b), r, min_rgb)
    min_rgb = np.where((g <= r) & (g <= b), g, min_rgb)
    min_rgb = np.where((b <= g) & (b <= r), b, min_rgb)
    img_s = 1 - 3 * min_rgb / (r + g + b + eps)  # S分量

    num = ((r - g) + (r - b)) / 2
    den = np.sqrt((r - g) ** 2 + (r - b) * (g - b))
    theta = np.arccos(num / (den + eps))
    img_h = np.where((b - g) > 0, 2 * np.pi - theta, theta)  # H分量
    img_h = np.where(img_s == 0, 0, img_h)

    img_h = img_h / (2 * np.pi)  # 归一化
    temp_s = img_s - np.min(img_s)
    temp_i = img_i - np.min(img_i)
    img_s = temp_s / np.max(temp_s)
    img_i = temp_i / np.max(temp_i)

    image_hsi = cv2.merge([img_h, img_s, img_i])
    return img_h, img_s, img_i, image_hsi

def get_alpha_whole(alpha_rgb,wavelength,rgblength):
    alpha = np.zeros((224), dtype=np.float)
    for i in range(224):
        alpha[i] = (rgblength/wavelength[i])*alpha_rgb
    alpha[11],alpha[19],alpha[28] = alpha_rgb,alpha_rgb,alpha_rgb
    return alpha

def get_alpha1(s,i,F):          # 正确
    FM = np.multiply(1-F,s)
    FN = np.multiply(F,i)
    F_hist,F_bins = np.histogram(F, bins=2000)
    F_d = np.cumsum(F_hist) / float(F.size)
    threshold = 0
    for i in range(2000 - 1, 0, -1):
        if F_d[i] <= 0.999:  #
            threshold = i
            break
    F_bright = np.mean(F[F>=F_bins[threshold]])
    threshold = 0
    for i in range(2000 - 1, 0, -1):
        if F_d[i] <= 0.001:  #
            threshold = i
            break
    F_dark = np.mean(F[F<=F_bins[threshold]])
    FM_hist, FM_bins = np.histogram(FM, bins=2000)
    FM_d = np.cumsum(FM_hist) / float(FM.size)
    threshold = 0
    for i in range(2000 - 1, 0, -1):
        if FM_d[i] <= 0.999:  #
            threshold = i
            break
    H2 = np.mean(FM[FM>=FM_bins[threshold]])
    FN_hist, FN_bins = np.histogram(FN, bins=2000)
    FN_d = np.cumsum(FN_hist) / float(FN.size)
    threshold = 0
    for i in range(2000 - 1, 0, -1):
        if FN_d[i] <= 0.999:  #
            threshold = i
            break
    H1 = np.mean(FN[FN >= FN_bins[threshold]])
    alpha = (H1-H2)/(F_bright-F_dark)
    return alpha

def get_clear(img,f):
    img = img.numpy()
    f = f.numpy()
    img = np.transpose(img,(0,2,3,1))	# BHWC
    b,h,w,c = img.shape
    haze_free = np.zeros((b,h,w,c), dtype=np.float) 	# bhwc
    for i in range(b):
        img_temp = img[i]	# hwc
        f_temp = f[i,1,:,:]		# hw
        img_RGB = spectral.get_rgb(img_temp,[28,19,11])
        H_1, S, I, img_hsi = Rgb2Hsi(img_RGB[:, :, 0], img_RGB[:, :, 1], img_RGB[:, :, 2])
        alpha_temp = get_alpha1(S,I,f_temp)
        band_rgb = 553.6546
        alpha = get_alpha_whole(alpha_temp,wavelength=data_1.wavelength_aviris(),rgblength=band_rgb)
        for j in range(c):
            haze_free[i,:,:,j] = img_temp[:,:,j]-alpha[j]*f_temp
    haze_free = np.transpose(haze_free,(0,3,1,2))	# bchw
    haze_free = torch.Tensor(haze_free)
    return haze_free