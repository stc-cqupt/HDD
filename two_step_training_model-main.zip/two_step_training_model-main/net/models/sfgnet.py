import torch.nn as nn
import torch
import torchvision.utils as vutils


class PAB(nn.Module):  # PSEB
    def __init__(self, channel):
        super(PAB, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.ka = nn.Sequential(
            nn.Conv2d(channel, channel // 8, 1, padding=0, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel // 8, channel, 1, padding=0, bias=True),
            nn.Sigmoid()
        )

    def forward(self, f,x):
        a = self.avg_pool(x)
        a = self.ka(a)
        j = x - torch.mul(f, a)
        return j


def default_conv(in_channels, out_channels, kernel_size, bias=True):
    return nn.Conv2d(in_channels, out_channels, kernel_size,padding=(kernel_size//2), bias=bias)

class SCPA(nn.Module):     # SAB
    def __init__(self, channel):
        super(SCPA, self).__init__()
        self.pdu = PAB(channel)
        self.conv4 = nn.Conv2d(channel, channel, 3, padding=(3//2), bias=True)
        self.conv5 = nn.Conv2d(channel, channel, 3, padding=(3//2), bias=True)
        self.ca_av = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channel, channel // 8, 1, padding=0, bias=True),
            nn.Conv2d(channel//8, channel, 1, padding=0, bias=True),
            nn.Sigmoid()
        )
        self.ca_max = nn.Sequential(
            nn.AdaptiveMaxPool2d(1),
            nn.Conv2d(channel, channel // 8, 1, padding=0, bias=True),
            nn.Conv2d(channel//8, channel, 1, padding=0, bias=True),
            nn.Sigmoid()
        )
        self.conv6_sigmod = nn.Sequential(
            nn.Conv2d(channel, 1, 1, padding=0, bias=True),
            nn.Sigmoid()
        )
        self.conv7 = nn.Conv2d(channel, channel, 3, padding=(3//2), bias=True)
        self.conv8 = nn.Conv2d(channel, channel, 3, padding=(3//2), bias=True)

    def forward(self,f, x0):
        # x = self.conv1(x0)
        # x1 = self.conv2(x)
        # x2 = self.conv3(x)
        # x = torch.cat([x1,x2],dim=1)
        # x = self.satail(x)
        # x = x*x0
        x = self.pdu(f, x0)
        x = self.conv4(x)
        x3 = self.conv5(x)
        xc_1 = self.ca_av(x3)
        xc_2 = self.ca_max(x3)
        x = xc_1+xc_2
        x = x*x3
        x4 = self.conv6_sigmod(x)
        x5 = self.conv7(x)
        x = x4 * x5
        x = self.conv8(x)
        return x

class RB(nn.Module):
    def __init__(self, channel):
        super(RB, self).__init__()
        self.FW = nn.Sequential(
            nn.Conv2d(channel, channel, 3, padding=(3//2), bias=True),
            nn.Conv2d(channel, channel, 1, padding=0, bias=True),
            nn.Conv2d(channel, channel, 3, padding=(3 // 2), bias=True),
        )
        self.conv = nn.Conv2d(channel, channel, 1, padding=0, bias=True)

    def forward(self, x):
        x1 = self.FW(x)
        x2 = self.conv(x)
        return x1+x2



class fusion(nn.Module):  # FCB
    def __init__(self, channel):
        super(fusion, self).__init__()
        self.conv1 = nn.Conv2d(channel, channel, 1, padding=0, bias=True)
        self.at =  nn.Sequential(
                nn.Conv2d(channel, channel // 8, 1, padding=0, bias=True),
                nn.ReLU(inplace=True),
                nn.Conv2d(channel // 8, 1, 1, padding=0, bias=True),
                nn.Sigmoid()
        )
        self.conv4 = nn.Conv2d(channel,channel,1, padding=0, bias=True)
        self.conv5 = nn.Conv2d(channel*2,channel,1, padding=0, bias=True)
        #self.conv6 = nn.Conv2d(channel//8,channel,3, padding=(3 // 2), bias=True)

    def forward(self, x1,x2):   # x1:来自较低波长的光谱
        _, _, H, W = x1.shape
        fre_x1 = torch.fft.rfft2(x1, norm='backward', dim=(-2, -1))
        mag_x1 = torch.abs(fre_x1)
        pha_x1 = torch.angle(fre_x1)
        mag_x1 = self.conv1(mag_x1)
        fre_x1_out = torch.complex(mag_x1 * torch.cos(pha_x1), mag_x1 * torch.sin(pha_x1))
        x1_out = torch.fft.irfft2(fre_x1_out, s=(H, W), norm='backward')
        x1_out = self.at(x1_out)
        x1_out = x1_out * x1
        #x1 = self.conv4(x1)
        x1 = x1+ x1_out
        x = torch.cat([x1,x2],dim=1)
        x = self.conv5(x)
        return x

class mid_group(nn.Module):
    def __init__(self, channel, inchannel):
        super(mid_group, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(inchannel, channel, 3, padding=(3//2), bias=True),
            nn.Conv2d(channel, channel, 3, padding=(3 // 2), bias=True),
        )
        self.scpa1 = SCPA(channel=channel)
        self.scpa2 = SCPA(channel=channel)
        self.scpa3 = SCPA(channel=channel)
        self.f1 = fusion(channel)
        self.f2 = fusion(channel)
        self.f3 = fusion(channel)
        self.rs1 = RB(channel)
        self.rs2 = RB(channel)

    def forward(self,f, x0,x1,x2,x3):
        y1 = self.conv(x0)
        y2 = self.scpa1(f,x1)
        y2 = self.f1(y1,y2)
        y2 = self.rs1(y2)
        y3 = self.scpa2(f,x2)
        y3 = self.f2(y2,y3)
        y3 = self.rs2(y3)
        y3_1 = self.scpa3(f,x3)
        y3 = self.f3(y3,y3_1)
        return y1,y2,y3





class sfgnet(nn.Module):     # dim：64 kernel_size：3×3
    def __init__(self):
        super(sfgnet, self).__init__()
        self.dim = 256
        self.mg1 = mid_group(channel=self.dim,inchannel=41)
        self.mg2 = mid_group(channel=self.dim, inchannel=24)
        self.mg3 = mid_group(channel=self.dim, inchannel=35)
        pre_process = [nn.Conv2d(30, self.dim, 3, padding=(3//2), bias=True),
                       nn.Conv2d(self.dim, self.dim, 3, padding=(3//2), bias=True)]
        post_precess = [nn.Conv2d(self.dim, 224, 3, padding=(3//2), bias=True)]
        self.pre = nn.Sequential(*pre_process)
        self.post = nn.Sequential(*post_precess)
        self.conv1 = nn.Conv2d(28, self.dim, 3, padding=(3//2), bias=True)
        self.conv2 = nn.Conv2d(self.dim, self.dim, 3, padding=(3//2), bias=True)
        self.conv3 = nn.Conv2d(44, self.dim, 3, padding=(3//2), bias=True)
        self.conv4 = nn.Conv2d(self.dim, self.dim, 3, padding=(3//2), bias=True)
        self.conv5 = nn.Conv2d(172, self.dim, 3, padding=(3//2), bias=True)
        self.dpconv = nn.Conv2d(self.dim, self.dim, 3, padding=(3//2), groups=self.dim,bias=True)   # 比普通卷积多加了一个groups
        self.conv6 = nn.Conv2d(self.dim, 172, 3, padding=(3//2), bias=True)
        self.scpa1 = SCPA(channel=self.dim)
        self.scpa2 = SCPA(channel=self.dim)
        self.scpa3 = SCPA(channel=self.dim)
        self.scpa4 = SCPA(channel=self.dim)
        self.f1 = fusion(self.dim)
        self.f2 = fusion(self.dim)
        self.f3 = fusion(self.dim)
        self.rs1 = RB(self.dim)
        self.rs2 = RB(self.dim)
        self.rs3 = RB(self.dim)
        self.rs4 = RB(self.dim)
        #self.SP = GCN_SGR(in_channel=self.dim, state_channel=256, node_num=256)  # spatial graph
        #self.CA = GCN_CGR(in_channel=self.dim, state_channel=256, node_num=512)  # channel graph



    def forward(self,x,f):        # x维度B 224 256 256a
        # 将输入进行分组
        x1 = x[:, 0:28]
        x2 = x[:, 28:69]
        x3 = x[:, 69:93]
        x4 = x[:, 93:128]
        x5 = x[:, 128:172]
        x5_1 = self.conv3(x5)
        x5_1 = self.conv4(x5_1)
        x5_2 = self.rs3(x5_1)
        x5_3 = self.rs4(x5_2)
        x4_1, x4_2, x4_3 = self.mg3(f,x4,x5_1,x5_2,x5_3)
        x3_1,x3_2,x3_3 = self.mg2(f,x3,x4_1,x4_2,x4_3)
        x2_1,x2_2,x2_3 = self.mg1(f,x2,x3_1,x3_2,x3_3)
        x2_1 = self.scpa1(f,x2_1)
        x2_2 = self.scpa2(f,x2_2)
        #x2_3 = self.scpa3(f, x2_3)
        x2_3 = self.scpa3(f,x3_3)
        x1 = self.conv1(x1)
        x1 = self.conv2(x1)
        x1 = self.f1(x1,x2_1)
        x1 = self.rs1(x1)
        x1 = self.f2(x1,x2_2)
        x1 = self.f3(x1,x2_3)
        x1 = self.scpa4(f,x1)
        x1 = self.rs2(x1)
        x = self.conv5(x)
        x = self.dpconv(x)
        x = x + x1
        x = self.conv6(x)
        return x









