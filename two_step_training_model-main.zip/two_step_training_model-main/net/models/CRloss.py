# -*- coding: utf-8 -*-
# Torch
import torch.nn as nn
import torch.nn.functional as F
import torch
import tifffile as tif
import torch.optim as optim
from torch.nn import init

# utils
import math
import os
import datetime
import numpy as np
import joblib

from tqdm import tqdm

def delete_not_useful_bands(x):
    x1 = x[10:103]
    x2 = x[116:151]
    x3 = x[170:214]
    y = torch.cat([x1,x2,x3],dim=0)
    return y


class HeEtAl(nn.Module):
    """
    MULTI-SCALE 3D DEEP CONVOLUTIONAL NEURAL NETWORK FOR HYPERSPECTRAL
    IMAGE CLASSIFICATION
    Mingyi He, Bo Li, Huahui Chen
    IEEE International Conference on Image Processing (ICIP) 2017
    https://ieeexplore.ieee.org/document/8297014/
    """

    @staticmethod
    def weight_init(m):
        if isinstance(m, nn.Linear) or isinstance(m, nn.Conv3d):
            init.kaiming_uniform(m.weight)
            init.zeros_(m.bias)

    def __init__(self, input_channels, n_classes, patch_size=7):
        super(HeEtAl, self).__init__()
        self.input_channels = input_channels
        self.patch_size = patch_size

        self.conv1 = nn.Conv3d(1, 16, (11, 3, 3), stride=(3, 1, 1))
        self.conv2_1 = nn.Conv3d(16, 16, (1, 1, 1), padding=(0, 0, 0))
        self.conv2_2 = nn.Conv3d(16, 16, (3, 1, 1), padding=(1, 0, 0))
        self.conv2_3 = nn.Conv3d(16, 16, (5, 1, 1), padding=(2, 0, 0))
        self.conv2_4 = nn.Conv3d(16, 16, (11, 1, 1), padding=(5, 0, 0))
        self.conv3_1 = nn.Conv3d(16, 16, (1, 1, 1), padding=(0, 0, 0))
        self.conv3_2 = nn.Conv3d(16, 16, (3, 1, 1), padding=(1, 0, 0))
        self.conv3_3 = nn.Conv3d(16, 16, (5, 1, 1), padding=(2, 0, 0))
        self.conv3_4 = nn.Conv3d(16, 16, (11, 1, 1), padding=(5, 0, 0))
        self.conv4 = nn.Conv3d(16, 16, (3, 2, 2))
        self.pooling = nn.MaxPool2d((3, 2, 2), stride=(3, 2, 2))
        # the ratio of dropout is 0.6 in our experiments
        self.dropout = nn.Dropout(p=0.6)

        self.features_size = self._get_final_flattened_size()

        self.fc = nn.Linear(self.features_size, n_classes)

        self.apply(self.weight_init)

    def _get_final_flattened_size(self):
        with torch.no_grad():
            x = torch.zeros(
                (1, 1, self.input_channels, self.patch_size, self.patch_size)
            )
            x = self.conv1(x)
            x2_1 = self.conv2_1(x)
            x2_2 = self.conv2_2(x)
            x2_3 = self.conv2_3(x)
            x2_4 = self.conv2_4(x)
            x = x2_1 + x2_2 + x2_3 + x2_4
            x3_1 = self.conv3_1(x)
            x3_2 = self.conv3_2(x)
            x3_3 = self.conv3_3(x)
            x3_4 = self.conv3_4(x)
            x = x3_1 + x3_2 + x3_3 + x3_4
            x = self.conv4(x)
            _, t, c, w, h = x.size()
        return t * c * w * h

    def forward(self, x):   # b 1 c h w :1 1 172 128 128
        x = F.relu(self.conv1(x))   # b 1 c h w :1 16 54 126 126
        x2_1 = self.conv2_1(x)      # 1 16 54 126 126
        x2_2 = self.conv2_2(x)
        x2_3 = self.conv2_3(x)
        x2_4 = self.conv2_4(x)
        x = x2_1 + x2_2 + x2_3 + x2_4
        x = F.relu(x)
        x3_1 = self.conv3_1(x)
        x3_2 = self.conv3_2(x)
        x3_3 = self.conv3_3(x)
        x3_4 = self.conv3_4(x)
        x = x3_1 + x3_2 + x3_3 + x3_4
        x = F.relu(x)
        x = F.relu(self.conv4(x))
        x = x.view(-1, self.features_size)
        x = self.dropout(x)
        x = self.fc(x)
        return x

def read_HSI_tif(file_path):    #  img为ndarray(numpy的数组都是这种形式)格式
    img = tif.imread(file_path)
    return img

class ContrastLoss(nn.Module):
    def __init__(self, ablation=False):
        super(ContrastLoss, self).__init__()
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        ckp = torch.load(r"D:\大修3-31截止\two_step_training_model-main\trainedmodel\2023_07_05_21_05_20_epoch100_1.00.pth",
                         map_location=device)   # path to your corresponding data
        net = HeEtAl(input_channels=172, n_classes=17, patch_size=128)
        # net.load_state_dict(ckp['model'])
        net.load_state_dict(ckp)
        net.eval()
        self.net = net.to(device)
        self.l1 = nn.L1Loss(reduction='mean')
        self.weights = [ 1.0 / 16, 1.0 / 8, 1.0 / 2, 1.0]

    def forward(self,a,p,n):
        def get_mid_feature(x):  # x: B 1 CHW
            input_data = {}
            output_data = {}

            def get_activation(name):
                def hook(model, input, output):
                    input_data[name] = input[
                        0].detach()  # input type is tulple, only has one element, which is the tensor
                    output_data[name] = output.detach()  # output type is tensor

                return hook

            self.net.conv2_1.register_forward_hook(get_activation('conv2_1'))
            self.net.conv3_1.register_forward_hook(get_activation('conv3_1'))
            self.net.conv4.register_forward_hook(get_activation('conv4'))
            self.net.dropout.register_forward_hook(get_activation('drop'))
            x = self.net(x)  # 1,17  B 17
            f1 = input_data['conv2_1']  # 根据get_activation('conv2')设置的名字提取
            f2 = input_data['conv3_1']
            f3 = input_data['conv4']
            f4 = input_data['drop']
            return f1, f2, f3, f4

        def get_mid_features1(full):  # 完整的图像：bc 256 256
            full = full[:, None, :]
            x1 = full[:, :, :, 0:128, 0:128]  # 裁剪成四小块
            x2 = full[:, :, :, 0:128, 128:256]
            x3 = full[:, :, :, 128:256, 0:128]
            x4 = full[:, :, :, 128:256, 128:256]
            x1_1,x1_2,x1_3,x1_4 = get_mid_feature(x1)
            x2_1,x2_2,x2_3,x2_4 = get_mid_feature(x2)
            x3_1,x3_2,x3_3,x3_4 = get_mid_feature(x3)
            x4_1,x4_2,x4_3,x4_4 = get_mid_feature(x4)
            f1 = x1_1+x2_1+x3_1+x4_1
            f2 = x1_2+x2_2+x3_2+x4_2
            f3 = x1_3+x2_3+x3_3+x4_3
            f4 = x1_4+x2_4+x3_4+x4_4
            return f1,f2,f3,f4
        a_f1,a_f2,a_f3,a_f4 = get_mid_features1(a)
        p_f1,p_f2,p_f3,p_f4 = get_mid_features1(p)
        n_f1,n_f2,n_f3,n_f4 = get_mid_features1(n)
        r1 = ((self.l1(a_f1,p_f1))/(self.l1(a_f1,n_f1) + 1e-7))*self.weights[0]
        r2 = ((self.l1(a_f2,p_f2))/(self.l1(a_f2,n_f2) + 1e-7))*self.weights[1]
        r3 = ((self.l1(a_f3, p_f3)) / (self.l1(a_f3, n_f3) + 1e-7)) * self.weights[2]
        r4 = ((self.l1(a_f4,p_f4))/(self.l1(a_f4,n_f4) + 1e-7))*self.weights[3]
        return r1+r2+r3+r4

class ContrastLoss_simple(nn.Module):
    def __init__(self, ablation=False):
        super(ContrastLoss_simple, self).__init__()
        self.l1 = nn.L1Loss()

    def forward(self, a, p, n):
        ap = self.l1(a,p)
        an = self.l1(a,n)+ 1e-7
        result = ap/an
        return result

class amp_loss(nn.Module):
    def __init__(self, ablation=False):
        super(amp_loss, self).__init__()
        self.l1 = nn.L1Loss(reduction='mean')

    def forward(self,x,y):
        x_out = torch.fft.fft2(x,dim=(-2,-1))
        x_amp = torch.abs(x_out)
        y_out = torch.fft.fft2(y,dim=(-2,-1))
        y_amp = torch.abs(y_out)
        result = self.l1(x_amp,y_amp)
        return result


