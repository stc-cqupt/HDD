import sys,os
dir=os.path.abspath(os.path.dirname(__file__))
sys.path.append(dir)
from FFA import FFA
from sfgnet import sfgnet
from CRloss import ContrastLoss as Crloss
from CRloss import amp_loss as amploss