import torch,os,sys,torchvision,argparse
import torchvision.transforms as tfs
from metrics import psnr,ssim
from models import *
import time,math
import numpy as np
from torch.backends import cudnn
from torch import optim
import torch,warnings
from torch import nn
#from tensorboardX import SummaryWriter
import torchvision.utils as vutils
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
warnings.filterwarnings('ignore')
from option import opt,model_name,log_dir
from data_utils import *
from torchvision.models import vgg16
from models import sfgnet as sfgnet
from models import get_clear

print('model_name:',model_name)

models_={
	'ffa':FFA(gps=opt.gps,blocks=opt.blocks),
}

loaders_={
	'HSI_train':HSI_train_loader,
	'HSI_test':HSI_test_loader,
}

start_time=time.time()
T=opt.steps	
def lr_schedule_cosdecay(t,T,init_lr=opt.lr):
	lr=0.5*(1+math.cos(t*math.pi/T))*init_lr
	return lr

def get_rgb(x):
	r = x[:,29,:];r  = r[:,None,:]
	g = x[:,20,:];g = g[:,None,:]
	b = x[:,12,:];b = b[:,None,:]
	y = torch.cat((r,g,b),1)
	return y

def delete_not_useful_bands(x):
	x1 = x[:,10:103]
	x2 = x[:,116:151]
	x3 = x[:,170:214]
	y = torch.cat([x1,x2,x3],dim=1)
	return y

def train(net_hsi,net,loader_train,loader_test,optim,criterion):
	losses=[]
	start_step=0
	max_ssim=0
	max_psnr=0
	if opt.resume and os.path.exists(opt.model_dir):
		print(f'resume from {opt.model_dir}')
		ckp=torch.load(opt.model_dir)
		losses=ckp['losses']
		net.load_state_dict(ckp['model'])
		start_step=ckp['step']
		max_ssim=ckp['max_ssim']
		max_psnr=ckp['max_psnr']
		print(f'start_step:{start_step} start training ---')
	else :
		print('train from scratch *** ')
	for step in range(start_step+1,opt.steps+1):
		net.train()
		lr=opt.lr
		if not opt.no_lr_sche:
			lr=lr_schedule_cosdecay(step,T)
			for param_group in optim.param_groups:
				param_group["lr"] = lr  
		x,y=next(iter(loader_train))

		f = get_clear.get_hazeintensitymap_F(x)
		x_hsinet = get_clear.get_clear(x,f)
		x_hsinet = x_hsinet.to(opt.device);f = f.to(opt.device)
		x_hsinet = delete_not_useful_bands(x_hsinet)
		x_hsinet = net_hsi(x_hsinet,f)
		x = delete_not_useful_bands(x)
		y= delete_not_useful_bands(y)


		x=x.to(opt.device);y=y.to(opt.device);
		out=net(x_hsinet,x)
		loss=criterion[0](out,y)
		
		loss.backward()
		
		optim.step()
		optim.zero_grad()
		losses.append(loss.item())
		print(f'\rtrain loss : {loss.item():.5f}| step :{step}/{opt.steps}|lr :{lr :.7f} |time_used :{(time.time()-start_time)/60 :.1f}',end='',flush=True)

		if step % opt.eval_step ==0 :
			with torch.no_grad():
				ssim_eval,psnr_eval=test(net_hsi,net,loader_test, max_psnr,max_ssim,step)

			print(f'\nstep :{step} |ssim:{ssim_eval:.4f}| psnr:{psnr_eval:.4f}')

			if ssim_eval > max_ssim and psnr_eval > max_psnr :
				max_ssim=max(max_ssim,ssim_eval)
				max_psnr=max(max_psnr,psnr_eval)
				torch.save({
							'step':step,
							'max_psnr':max_psnr,
							'max_ssim':max_ssim,
							'losses':losses,
							'model':net.state_dict()
				},opt.model_dir)
				print(f'\n model saved at step :{step}| max_psnr:{max_psnr:.4f}|max_ssim:{max_ssim:.4f}')

	np.save(f'./numpy_files/{model_name}_{opt.steps}_losses.npy',losses)

def test(net_hsi,net,loader_test,max_psnr,max_ssim,step):
	net.eval()
	torch.cuda.empty_cache()
	ssims=[]
	psnrs=[]
	#s=True
	for i ,(inputs,targets) in enumerate(loader_test):
		# HSI
		f = get_clear.get_hazeintensitymap_F(inputs)
		inputs_hsinet = get_clear.get_clear(inputs,f)
		inputs_hsinet = inputs_hsinet.to(opt.device);f = f.to(opt.device)
		inputs_hsinet = delete_not_useful_bands(inputs_hsinet)
		inputs_hsinet = net_hsi(inputs_hsinet,f)
		targets= delete_not_useful_bands(targets)
		inputs = delete_not_useful_bands(inputs)

		inputs=inputs.to(opt.device);targets=targets.to(opt.device)
		pred=net(inputs_hsinet,inputs)
		ssim1=ssim(pred,targets).item()
		psnr1=psnr(pred,targets)
		ssims.append(ssim1)
		psnrs.append(psnr1)
	return np.mean(ssims) ,np.mean(psnrs)


if __name__ == "__main__":
	loader_train=loaders_[opt.trainset]
	loader_test=loaders_[opt.testset]
	net=models_[opt.net]
	net=net.to(opt.device)
	if opt.device=='cuda':
		net=torch.nn.DataParallel(net)
		cudnn.benchmark=True
	model_dir_hsi =r"D:\大修3-31截止\two_step_training_model-main\trainedmodel\HSI_train_sfgnet.pk"  # path to your corresponding data
	ckp_hsi = torch.load(model_dir_hsi,map_location=opt.device)
	net_hsi = sfgnet()
	net_hsi = nn.DataParallel(net_hsi)
	net_hsi.load_state_dict(ckp_hsi['model'])
	net_hsi.eval()
	net_hsi = net_hsi.to(opt.device)
	criterion = []
	criterion.append(nn.L1Loss().to(opt.device))
	optimizer = optim.Adam(params=filter(lambda x: x.requires_grad, net.parameters()),lr=opt.lr, betas = (0.9, 0.999), eps=1e-08)
	optimizer.zero_grad()
	train(net_hsi,net,loader_train,loader_test,optimizer,criterion)
	

