import spectral
import torch, os, sys, torchvision, argparse
import torchvision.transforms as tfs
from metrics import psnr, ssim
from models import *
import cv2
import time, math
import numpy as np
from torch.backends import cudnn
from torch import optim
from data_1 import wavelength_aviris
import torch, warnings
from torch import nn
# from tensorboardX import SummaryWriter
import torchvision.utils as vutils
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
warnings.filterwarnings('ignore')
from option import opt, model_name, log_dir
from data_utils import *
from torchvision.models import vgg16


models_ = {
    #'fpgnet': fpgnet()
    'sfgnet': sfgnet()
}
loaders_ = {
    'HSI_train': HSI_train_loader,
    'HSI_test': HSI_test_loader,
}
start_time = time.time()
T = opt.steps


def lr_schedule_cosdecay(t, T, init_lr=opt.lr):
    lr = 0.5 * (1 + math.cos(t * math.pi / T)) * init_lr
    return lr


def get_hazeintensitymap_F(x):
    # x = x.cpu()
    x = x.numpy()
    arr_visible = x[:, 0:30]
    arr_infrared = x[:, 173:209]
    B, C_visible, H, W = arr_visible.shape
    B, C_infrared, H, W = arr_infrared.shape
    sum_vis = np.zeros((B, W, H), dtype=np.float)
    sum_inf = np.zeros((B, W, H), dtype=np.float)
    for i in range(C_visible):
        sum_vis = sum_vis + arr_visible[:, i]
    var_vis = sum_vis / C_visible
    for i in range(C_infrared):
        sum_inf = sum_inf + arr_infrared[:, i]
    var_inf = sum_inf / C_infrared  # BHW
    F = var_inf - var_vis  # BHW
    F_final = np.zeros((256, B, 256, 256), dtype=np.float)
    for i in range(256):
        F_final[i] = F
    F_final = np.transpose(F_final, (1, 0, 2, 3))
    F_final = torch.Tensor(F_final)
    return F_final


def Rgb2Hsi(r, g, b):
    eps = 1e-8
    img_i = (r + g + b) / 3  # I分量

    img_h = np.zeros(r.shape, dtype=np.float32)
    img_s = np.zeros(r.shape, dtype=np.float32)
    min_rgb = np.zeros(r.shape, dtype=np.float32)
    # 获取RGB中最小值
    min_rgb = np.where((r <= g) & (r <= b), r, min_rgb)
    min_rgb = np.where((g <= r) & (g <= b), g, min_rgb)
    min_rgb = np.where((b <= g) & (b <= r), b, min_rgb)
    img_s = 1 - 3 * min_rgb / (r + g + b + eps)  # S

    num = ((r - g) + (r - b)) / 2
    den = np.sqrt((r - g) ** 2 + (r - b) * (g - b))
    theta = np.arccos(num / (den + eps))
    img_h = np.where((b - g) > 0, 2 * np.pi - theta, theta)  # H
    img_h = np.where(img_s == 0, 0, img_h)

    img_h = img_h / (2 * np.pi)
    temp_s = img_s - np.min(img_s)
    temp_i = img_i - np.min(img_i)
    img_s = temp_s / np.max(temp_s)
    img_i = temp_i / np.max(temp_i)

    image_hsi = cv2.merge([img_h, img_s, img_i])
    return img_h, img_s, img_i, image_hsi


def get_alpha_whole(alpha_rgb, wavelength, rgblength):
    alpha = np.zeros((224), dtype=np.float)
    for i in range(224):
        alpha[i] = (rgblength / wavelength[i]) * alpha_rgb
    alpha[11], alpha[19], alpha[28] = alpha_rgb, alpha_rgb, alpha_rgb
    return alpha


def get_alpha1(s, i, F):
    FM = np.multiply(1 - F, s)
    FN = np.multiply(F, i)
    F_hist, F_bins = np.histogram(F, bins=2000)
    F_d = np.cumsum(F_hist) / float(F.size)
    threshold = 0
    for i in range(2000 - 1, 0, -1):
        if F_d[i] <= 0.999:  #
            threshold = i
            break
    F_bright = np.mean(F[F >= F_bins[threshold]])
    threshold = 0
    for i in range(2000 - 1, 0, -1):
        if F_d[i] <= 0.001:  #
            threshold = i
            break
    F_dark = np.mean(F[F <= F_bins[threshold]])
    FM_hist, FM_bins = np.histogram(FM, bins=2000)
    FM_d = np.cumsum(FM_hist) / float(FM.size)
    threshold = 0
    for i in range(2000 - 1, 0, -1):
        if FM_d[i] <= 0.999:  #
            threshold = i
            break
    H2 = np.mean(FM[FM >= FM_bins[threshold]])
    FN_hist, FN_bins = np.histogram(FN, bins=2000)
    FN_d = np.cumsum(FN_hist) / float(FN.size)
    threshold = 0
    for i in range(2000 - 1, 0, -1):
        if FN_d[i] <= 0.999:  #
            threshold = i
            break
    H1 = np.mean(FN[FN >= FN_bins[threshold]])
    alpha = (H1 - H2) / (F_bright - F_dark)
    return alpha


def delete_not_useful_bands(x):
    x1 = x[:, 10:103]
    x2 = x[:, 116:151]
    x3 = x[:, 170:214]
    y = torch.cat([x1, x2, x3], dim=1)
    return y


def get_clear(img, f):
    img = img.numpy()
    f = f.numpy()
    img = np.transpose(img, (0, 2, 3, 1))  # BHWC
    b, h, w, c = img.shape
    haze_free = np.zeros((b, h, w, c), dtype=np.float)  # bhwc
    for i in range(b):
        img_temp = img[i]  # hwc
        f_temp = f[i, 1, :, :]  # hw
        img_RGB = spectral.get_rgb(img_temp, [28, 19, 11])
        H_1, S, I, img_hsi = Rgb2Hsi(img_RGB[:, :, 0], img_RGB[:, :, 1], img_RGB[:, :, 2])
        alpha_temp = get_alpha1(S, I, f_temp)
        band_rgb = 553.6546
        alpha = get_alpha_whole(alpha_temp, wavelength=wavelength_aviris(), rgblength=band_rgb)
        for j in range(c):
            haze_free[i, :, :, j] = img_temp[:, :, j] - alpha[j] * f_temp
    haze_free = np.transpose(haze_free, (0, 3, 1, 2))  # bchw
    haze_free = torch.Tensor(haze_free)
    return haze_free


def train(net, loader_train, loader_test, optim, criterion):
    losses = []
    start_step = 0
    max_ssim = 0
    max_psnr = 0
    if opt.resume and os.path.exists(opt.model_dir_hsi):
        print(f'resume from {opt.model_dir_hsi}')
        ckp = torch.load(opt.model_dir_hsi)
        losses = ckp['losses']
        net.load_state_dict(ckp['model'])
        start_step = ckp['step']
        max_ssim = ckp['max_ssim']
        max_psnr = ckp['max_psnr']
        print(f'start_step:{start_step} start training ---')
    else:
        print('train from scratch *** ')
    for step in range(start_step + 1, opt.steps + 1):
        net.train()
        lr = opt.lr
        if not opt.no_lr_sche:
            lr = lr_schedule_cosdecay(step, T)
            for param_group in optim.param_groups:
                param_group["lr"] = lr
        x, y = next(iter(loader_train))
        f = get_hazeintensitymap_F(x)
        x = get_clear(x, f)
        f = f.to(opt.device)
        x = x.to(opt.device);
        y = y.to(opt.device)
        x = delete_not_useful_bands(x)
        y = delete_not_useful_bands(y)
        n = x
        out = net(x, f)
        loss = criterion[0](out, y)
        loss2 = criterion[1](out, y, n)
        loss3 = criterion[2](out, y)
        # loss = loss + 0.5*loss2 + 0.02*loss3 jiandan
        loss = loss + 0.1 * loss2 + 0.02 * loss3

        loss.backward()

        optim.step()
        optim.zero_grad()
        losses.append(loss.item())
        print(
            f'\rtrain loss : {loss.item():.5f}| step :{step}/{opt.steps}|lr :{lr :.7f} |time_used :{(time.time() - start_time) / 60 :.1f}',
            end='', flush=True)



        if step % opt.eval_step == 0:
            with torch.no_grad():
                ssim_eval, psnr_eval = test(net, loader_test, max_psnr, max_ssim, step)

            print(f'\nstep :{step} |ssim:{ssim_eval:.4f}| psnr:{psnr_eval:.4f}')

            if ssim_eval > max_ssim and psnr_eval > max_psnr:
                max_ssim = max(max_ssim, ssim_eval)
                max_psnr = max(max_psnr, psnr_eval)
                torch.save({
                    'step': step,
                    'max_psnr': max_psnr,
                    'max_ssim': max_ssim,
                    'losses': losses,
                    'model': net.state_dict()
                }, opt.model_dir_hsi)
                print(f'\n model saved at step :{step}| max_psnr:{max_psnr:.4f}|max_ssim:{max_ssim:.4f}')



def test(net, loader_test, max_psnr, max_ssim, step):
    net.eval()
    torch.cuda.empty_cache()
    ssims = []
    psnrs = []
    for i, (inputs, targets) in enumerate(loader_test):
        f = get_hazeintensitymap_F(inputs)
        inputs = get_clear(inputs, f)
        f = f.to(opt.device)
        inputs = inputs.to(opt.device);
        targets = targets.to(opt.device)
        inputs = delete_not_useful_bands(inputs)
        targets = delete_not_useful_bands(targets)
        pred = net(inputs, f)
        ssim1 = ssim(pred, targets).item()
        psnr1 = psnr(pred, targets)
        ssims.append(ssim1)
        psnrs.append(psnr1)
    return np.mean(ssims), np.mean(psnrs)


if __name__ == "__main__":
    loader_train = loaders_[opt.trainset]
    loader_test = loaders_[opt.testset]
    net = models_[opt.net]
    net = net.to(opt.device)
    if opt.device == 'cuda':
        net = torch.nn.DataParallel(net)
        cudnn.benchmark = True
    criterion = []
    criterion.append(nn.L1Loss().to(opt.device))
    # criterion.append(nn.MSELoss(reduction='mean').to(opt.device))
    # criterion.append(crsimple().to(opt.device))
    criterion.append(Crloss().to(opt.device))
    criterion.append(amploss().to(opt.device))
    optimizer = optim.Adam(params=filter(lambda x: x.requires_grad, net.parameters()), lr=opt.lr, betas=(0.9, 0.999),
                           eps=1e-08)
    optimizer.zero_grad()
    train(net, loader_train, loader_test, optimizer, criterion)


