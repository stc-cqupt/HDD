import scipy
import torch.utils.data as data
import torchvision.transforms as tfs
import tifffile as tif
from torchvision.transforms import functional as FF
import os,sys
sys.path.append('.')
sys.path.append('..')
import numpy as np
import torch
import random
from PIL import Image
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt
from torchvision.utils import make_grid
from metrics import *
import scipy.ndimage
from option import opt
BS=opt.bs
print(BS)


def tensorShow(tensors,titles=None):
        '''
        t:BCWH
        '''
        fig=plt.figure()
        for tensor,tit,i in zip(tensors,titles,range(len(tensors))):
            img = make_grid(tensor)
            npimg = img.numpy()
            ax = fig.add_subplot(211+i)
            ax.imshow(np.transpose(npimg, (1, 2, 0)))
            ax.set_title(tit)
        plt.show()



def read_HSI_tif(file_path):
    img = tif.imread(file_path)
    return img

class HDD_Dataset(data.Dataset):
    def __init__(self,path,train,format='.tif'):
        super(HDD_Dataset,self).__init__()
        self.train=train
        self.format=format
        self.haze_imgs_dir=os.listdir(os.path.join(path,'haze'))
        self.haze_imgs=[os.path.join(path,'haze',img) for img in self.haze_imgs_dir]
        self.clear_dir=os.path.join(path,'clear')
    def __getitem__(self, index):
        haze = read_HSI_tif(self.haze_imgs[index])
        clear_name = self.haze_imgs_dir[index]
        clear = read_HSI_tif(os.path.join(self.clear_dir,clear_name))
        haze,clear=self.augData(haze,clear)
        return haze,clear
    def augData(self,data,target):
        if self.train:
            rand_rot=random.randint(0,3)
            data = scipy.ndimage.rotate(data,angle=90*rand_rot)
            target=scipy.ndimage.rotate(target,angle=90*rand_rot)
        data = np.transpose(data,(2,0,1))
        target = np.transpose(target, (2,0,1))
        data=torch.Tensor(data)
        target=torch.Tensor(target)
        return  data ,target
    def __len__(self):
        return len(self.haze_imgs)


import os
pwd=os.getcwd()
print(pwd)
path=r"E:\DATA_TRAIN"  # path to your corresponding data
HSI_train_loader = DataLoader(dataset=HDD_Dataset(path+'/train',train=True),batch_size=BS,shuffle=True)
HSI_test_loader=DataLoader(dataset=HDD_Dataset(path+'/test',train=False),batch_size=1,shuffle=False)


if __name__ == "__main__":
    pass
