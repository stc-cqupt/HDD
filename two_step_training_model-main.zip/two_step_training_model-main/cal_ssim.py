import tifffile as tif
import spectral as spy
import torch
from net.metrics import ssim,psnr
import torchvision
import os
import cv2
import spectral.io.envi as envi
import matplotlib.pyplot as plt
from net.metrics import psnr,ssim
import numpy as np
from net.models.FFA import FFA
import torch.nn as nn
from net.models.sfgnet import sfgnet
import imgvision as iv
from net.models import get_clear

def read_HSI_tif(file_path):
    img = tif.imread(file_path)
    return img

def delete_not_useful_bands(x):
    x1 = x[:,10:103]
    x2 = x[:,116:151]
    x3 = x[:,170:214]
    y = torch.cat([x1,x2,x3],dim=1)
    return y

imgs_haze = os.listdir(r"")
imgs_clear = os.listdir(r"")
label = 0
device='cuda' if torch.cuda.is_available() else 'cpu'
ssim1 =  np.zeros((90), dtype=np.float) # 3
psnr1 = np.zeros((90), dtype=np.float)

models_={
	'ffa':FFA(gps=3,blocks=8),
}
net=models_['ffa']
model_dir=r""
ckp=torch.load(model_dir,map_location=device)
net=nn.DataParallel(net)
net.load_state_dict(ckp['model'])
net.eval()
net = net.to(device)


net=net.to(device)
model_dir_hsi =r""
ckp_hsi = torch.load(model_dir_hsi,map_location=device)
net_hsi = sfgnet()
net_hsi = nn.DataParallel(net_hsi)
net_hsi.load_state_dict(ckp_hsi['model'])
net_hsi.eval()
net_hsi = net_hsi.to(device)

for imgs in imgs_haze:
    img_haze_src = os.path.join(r"",imgs)
    img_clear_src = os.path.join(r"",imgs)
    img_nm = read_HSI_tif(img_haze_src)
    haze = np.transpose(img_nm, (2, 0, 1))  # CHW
    haze1 = torch.Tensor(haze)
    haze1 = haze1[None, ::]

    f = get_clear.get_hazeintensitymap_F(haze1)
    inputs_hsinet = get_clear.get_clear(haze1, f)
    inputs_hsinet = inputs_hsinet.to(device)
    f = f.to(device)
    inputs_hsinet = delete_not_useful_bands(inputs_hsinet)

    with torch.no_grad():
        inputs_hsinet = net_hsi(inputs_hsinet, f)
        haze1 = delete_not_useful_bands(haze1)
        haze1 = haze1.to(device)
        pred = net(inputs_hsinet,haze1)
    img_cl = read_HSI_tif(img_clear_src)
    img_cl = torch.tensor(img_cl)
    img_cl = np.transpose(img_cl, (2, 0, 1))
    img_cl = img_cl[None, :]
    img_cl = delete_not_useful_bands(img_cl)
    img_cl = img_cl.to(device)
    pred = pred.double()
    img_cl = img_cl.double()
    ssim1[label] = ssim(img_cl, pred)
    psnr1[label] = psnr(img_cl, pred)
    print('ssim:%f' % ssim1[label])
    print('psnr:%f' % psnr1[label])
    label = label + 1
print('ssim_mean:%f'%np.mean(ssim1))
print('psnr_mean:%f'%np.mean(psnr1))
np.savetxt("ssim.txt", ssim1, fmt = '%f', delimiter = ',')
np.savetxt("psnr.txt", psnr1, fmt = '%f', delimiter = ',')